#include "document.h"
#include <QSqlQuery>
#include <QtDebug>
#include<QObject>
#include<QSqlQueryModel>
#include <QMessageBox>
#include<QString>

document::document()
{
    id=0;
    nom="";
    prenom="";
    sujet_assise="";
}
document::document(int id,QString nom,QString prenom,QString sujet_assise)
{
        this->id=id;
        this->nom=nom;
        this->prenom=prenom;
         this->sujet_assise=sujet_assise;

}
int document:: getid()
{return id;}
QString document:: getnom ()
{return nom;}
QString  document::getprenom()
{ return prenom;}
QString  document::getsujet_assise()
{ return sujet_assise;}
void document:: setid(int id){
       this->id=id;
}
void document:: setnom(QString nom){
     this->nom=nom;
}
void document:: setprenom(QString prenom){
     this->prenom=prenom;
}
void document:: setsujet_assise(QString sujet_assise){
     this->sujet_assise=sujet_assise;
}

bool document:: ajouter()
{
   // bool test=false;

    QSqlQuery query;
   QString ID=QString::number(id);
    query.prepare("INSERT INTO DOCUMENT (ID, NOM, PRENOM,SUJET_ASSISE) "
                  "VALUES (:id, :nom, :prenom, :sujet_assise);");
    query.bindValue(":id", id);
    query.bindValue(":nom", nom);
    query.bindValue(":prenom", prenom);
    query.bindValue(":sujet_assise", sujet_assise);

   return query.exec();



}
bool document ::supprimer(int id){

    QSqlQuery query;

    query.prepare("Delete from DOCUMENT where id =:id  ");
    query.bindValue(0, id);

   return query.exec();
}

   QSqlQueryModel* document :: afficher()
   {
   QSqlQueryModel* model=new QSqlQueryModel();

    model->setQuery("select  * from DOCUMENT ");
    model->setHeaderData(0, Qt::Horizontal,QObject:: tr("ID"));
    model->setHeaderData(1, Qt::Horizontal,QObject:: tr("NOM"));
    model->setHeaderData(2, Qt::Horizontal,QObject:: tr("PRENOM"));
    model->setHeaderData(3, Qt::Horizontal,QObject:: tr("SUJET_ASSISE"));
    return model;
}
   bool document::modifier()
{     QSqlQuery query;
           QString ID= QString::number(id);
           query.prepare("UPDATE DOCUMENT SET ID=:ID, NOM=:NOM,PRENOM=:PRENOM,SUJET_ASSISE=:SUJET_ASSISE WHERE ID=:ID");
           query.bindValue(":ID",  id );
           query.bindValue(":NOM", nom);
           query.bindValue(":PRENOM",prenom);
           query.bindValue(":SUJET_ASSISE",sujet_assise);
         return query.exec();

}
  void document::chercheID(QTableView *table, int id)
   {
      QSqlQueryModel *model=new QSqlQueryModel();
      QSqlQuery *query =new QSqlQuery;
      query->prepare("select * from document where regexp_like(id,:id);");
      query->bindValue(":id",id);
      if(id==0)
      {
          query->prepare("select * from document;");
      }
      query->exec();
      model->setQuery(*query);
      table->setModel(model);
      table->show();
   }
   void document::clearTable(QTableView *table)
   {
       QSqlQueryModel *model=new QSqlQueryModel();
       model->clear();
       table->setModel(model);
   }
   QSqlQueryModel * document::tri_id()
   {QSqlQueryModel * model= new QSqlQueryModel();

   model->setQuery("select * from document order by id");
   model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
   model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
   model->setHeaderData(2, Qt::Horizontal, QObject::tr("prenom"));
   model->setHeaderData(3, Qt::Horizontal, QObject::tr("sujet_assise"));

       return model;
   }
   QSqlQueryModel * document::tri_nom()
   {QSqlQueryModel * model= new QSqlQueryModel();

   model->setQuery("select * from document order by nom");
   model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
   model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
   model->setHeaderData(2, Qt::Horizontal, QObject::tr("prenom"));
   model->setHeaderData(3, Qt::Horizontal, QObject::tr("sujet_assise"));

       return model;
   }
   QSqlQueryModel * document::tri_prenom()
   {QSqlQueryModel * model= new QSqlQueryModel();

   model->setQuery("select * from document order by prenom");
   model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
   model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
   model->setHeaderData(2, Qt::Horizontal, QObject::tr("prenom"));
   model->setHeaderData(3, Qt::Horizontal, QObject::tr("sujet_assise"));

       return model;
   }



