#ifndef AVOCATS_H
#define AVOCATS_H
#include <QString>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlQueryModel>
#include<qdatetimeedit.h>
#include<qdatetime.h>
#include <QVariant>
#include <QComboBox>

class Avocats
{
    QString CIN,Nom,Prenom,Mail,Tel,Salaire;
public:
    Avocats(){};
    Avocats(QString,QString,QString,QString,QString,QString);

    QString getCIN(){return CIN;}
    QString getNom(){return Nom;};
    QString getPrenom(){return Prenom;}
    QString getMail(){return Mail;}
    QString getTel(){return Tel;}
    QString getSalaire(){return Salaire;}


    void setCIN (QString c ){CIN=c;}
    void setNom(QString n){Nom=n;}
    void setPrenom(QString p){Prenom=p;}
    void setMail(QString m){ Mail=m;}
    void setTel(QString t){Tel=t;}
    void setSalaire(QString a){Salaire=a;}


    bool ajouteravocat();
    QSqlQueryModel * afficheravocat();
    bool modifieravocat(QString,QString,QString,QString,QString,QString);
    bool supprimeravocat(QString);
    QSqlQueryModel * cherchercinavocat(QString CIN);

};

#endif // AVOCATS_H
