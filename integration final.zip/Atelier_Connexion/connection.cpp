#include "connection.h"

Connection::Connection()
{

}

bool Connection::createconnect()
{bool test=false;
QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
db.setDatabaseName("Source_Projet2A");
db.setUserName("hajer");//inserer nom de l'utilisateur
db.setPassword("hajoura");//inserer mot de passe de cet util

if (db.open())
test=true;





    return  test;
}
