#include "avocats.h"
Avocats::Avocats(QString CIN,QString Nom, QString Prenom,QString Mail,  QString Tel,QString Salaire)
{
    this->CIN = CIN;
    this->Nom = Nom;
    this->Prenom = Prenom;
    this->Mail = Mail;
   this->Tel = Tel;
    this->Salaire=Salaire;
}
bool Avocats::ajouteravocat()
{
    QSqlQuery query;

    query.prepare("insert into Avocats (CIN, Nom, Prenom, Mail,  Tel, Salaire)" "values (:CIN, :Nom, :Prenom, :Mail, :Tel,:Salaire)");

    query.bindValue(":CIN",CIN);
    query.bindValue(":Nom",Nom);
    query.bindValue(":Prenom",Prenom);
    query.bindValue(":Mail",Mail);
    query.bindValue(":Tel",Tel);
    query.bindValue(":Salaire",Salaire);

    return query.exec();

}

QSqlQueryModel * Avocats::afficheravocat()
{
    QSqlQueryModel * model=new QSqlQueryModel();

    model->setQuery("select * from Avocats");
    model->setHeaderData(0,Qt::Horizontal,QObject::tr("CIN"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("NOM"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("PRENOM"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("MAIL"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("TEL"));
    model->setHeaderData(5,Qt::Horizontal,QObject::tr("SALAIRE"));


    return model;


}

bool Avocats::modifieravocat(QString CIN, QString Nom, QString Prenom, QString Mail, QString Tel,QString Salaire)
{
    QSqlQuery query;
    query.prepare("UPDATE Avocats SET CIN= :CIN,Nom= :Nom,Prenom= :Prenom,Mail= :Mail,Tel= :Tel,Salaire=:Salaire Where CIN= :CIN");
    query.bindValue(":CIN",CIN);
    query.bindValue(":Nom",Nom);
    query.bindValue(":Prenom",Prenom);
    query.bindValue(":Mail",Mail);
    query.bindValue(":Tel",Tel);
    query.bindValue(":Salaire",Salaire);
    return query.exec();
}

bool Avocats::supprimeravocat(QString CIN)
{
    QSqlQuery query;
    query.prepare("Delete from Avocats where CIN= :CIN");
    query.bindValue(":CIN",CIN);
    return query.exec();
}
QSqlQueryModel * Avocats::cherchercinavocat(QString CIN)
{
QSqlQueryModel * model = new QSqlQueryModel();
QSqlQuery query;
query.prepare("select * from Avocats WHERE CIN = :CIN");
query.bindValue(":CIN",CIN);
query.exec();
model ->setQuery(query);
model->setHeaderData(0,Qt::Horizontal,QObject::tr("CIN"));
model->setHeaderData(1,Qt::Horizontal,QObject::tr("NOM"));
model->setHeaderData(2,Qt::Horizontal,QObject::tr("PRENOM"));
model->setHeaderData(3,Qt::Horizontal,QObject::tr("MAIL"));
model->setHeaderData(4,Qt::Horizontal,QObject::tr("TEL"));
model->setHeaderData(5,Qt::Horizontal,QObject::tr("SALAIRE"));



return model;
}

