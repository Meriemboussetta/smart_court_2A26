#ifndef CLIENT_FONCTIONS_H
#define CLIENT_FONCTIONS_H
#include <QString>
#include <QDateEdit>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlQueryModel>

class Client_Fonctions
{

private:
    int CIN;
    QString nom;       // ======>>>>> LES ATTRIBUTS DE LA BASE DE DONNEES
    QString img;
    QString prenom;
    int age
;


public:
    Client_Fonctions(); // const NON PARAMETRE
    Client_Fonctions(int CIN,QString nom, QString prenom ,  int age,  QString img );//constructeur parametrer
    //Client_Fonctions(QString nom, QString prenom ,  int age,  QString img );

    bool ajouter();
    QSqlQuery afficherClient();
    bool supprimerClient(int CIN);   // ===============> LES METHODES CRUDS

    QSqlQuery afficherClient(int CIN);// recuperer information
    bool modifierClient(int CIN);
    QSqlQuery rechercher(QString rech);
    QSqlQuery trierclient(QString test);
    QStringList rechercherclient_completer();


};

#endif // CLIENT_FONCTIONS_H
