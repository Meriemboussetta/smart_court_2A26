#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "employee.h"
//#include <ActiveQt/QAxWidget>
#include "webaxwidget.h"
#include "Arduino.h"


/*************************************** INCLUDE MARIEM *********************************************************/
#include "document.h"
#include <QPdfWriter>
#include <QPainter>
#include <QDesktopServices>
#include <qdesktopservices.h>
//
#include <QMessageBox>
#include <QPlainTextEdit>
#include <QTextStream>
#include <QPainter>
#include <QTextStream>
#include <QFileDialog>
#include <QTextDocument>
#include <QtPrintSupport/QPrinter>
#include <QFileDialog>
#include <QTextDocument>
#include <strstream>
#include <QSystemTrayIcon>
#include <QRegExpValidator>
#include <QDesktopServices>
#include <QUrl>
#include <QPdfWriter>
#include <QFile>
#include <QCoreApplication>
#include <QTextStream>
#include <QSqlQuery>
//
#include <QtCharts>
#include "document.h"
#include <QDialog>
#include <QMainWindow>
#include <QSortFilterProxyModel>
//
#include <QtCore/QtGlobal>
#include "Arduino.h"
#include "QVBoxLayout"
#include <QtCharts>
#include "dialog_stats.h"

/**************************************INCLUDE CHI7I*********************************/
#include "audience.h"

/**************************INCLUDE RAYEN **********************************************/
#include "salle.h"


/**************************************INCLUDE OMAR************************************/
#include <QtSql/QSqlError>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQueryModel>
#include "avocats.h"
#include <QFileDialog>
#include <QDialog>

/**********************************INCLUDE HAJER******************************************/

#include"QListView"
#include"QStringListModel"
#include"QGraphicsTextItem"
#include"QGraphicsView"
#include "client_fonctions.h"
#include <QCompleter>
#include"Arduino.h"
#include"searchbox.h"
#include"googlesuggest.h"



namespace Ui
{
class MainWindow;
}

class QCamera;
class QCameraViewfinder;
class QCameraImageCapture;
class QVBoxLayout;
class QMenu;
class QAction;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void addPoint(double x,double y);
    void clearData();
    void plot();


 //QTabWidget *maps;
private slots:
    void on_ajouter_clicked();

    void on_supprimer_clicked();

    void on_pushButton_clicked();

    void on_pushButton_chercher_clicked();

    void on_tabWidget_currentChanged(int index);

    void on_tri_id_clicked();

    void on_tri_date_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_stat_clicked();

    void on_pushButton_3_clicked();

    void on_pb_prendre_photo_clicked();



    void on_ajouter_mariem_clicked();

    void on_recherche_mariem_clicked();

    void on_tri_id_mariem_clicked();

    void on_tri_nom_mariem_clicked();

    void on_tri_prenom_mariem_clicked();

    void on_pdf_mariem_clicked();

    void on_insertimg_mariem_clicked();

    void on_excel_mariem_clicked();

    void on_stat_mariem_clicked();

    void on_pb_supp_mariem_clicked();

    void on_modifier_mariem_1_clicked();

    void on_update_label_linkActivated_clicked();

    void on_connect_mariem_clicked();

    void on_Gestion_audience_clicked();

    void on_trie_chi7i_clicked();

    void on_stats_chi7i_clicked();

    void on_pdf_chi7i_clicked();

    void on_radioButton_chi7i_clicked();

    void on_ajouter_chi7i_clicked();

    void on_modifer_mod_chi7i_clicked();

    void on_supprimer_chi7i_clicked();

    void on_image_chi7i_clicked();

    void on_ok_chi7i_textChanged(const QString &arg1);

    void on_Gestion_des_Salle_clicked();

    void on_ajouter_rayen_clicked();

    void on_supprimer_rayen_clicked();

    void on_affichierstat_clicked();

    void on_searchbutton_rayen_clicked();

    void on_modifier_clicked();

    void on_buttonBox_Avocats_accepted();

    void on_buttonBox_2Avocats_accepted();

    void on_buttonBox_A_accepted();

    void on_pushButton_listeres_clicked();

    void on_radioButton_tricin_2_clicked();

    void on_radioButton_triprenom_2_clicked();

    void on_radioButton_trinom_2_clicked();

    void on_sendBtn_3_clicked();

    void on_Gestion_des_avocats_clicked();

    void on_gestion_employee_2_clicked();

    void on_gestion_documents_clicked();

    void on_Close_clicked();

    void on_Gestion_des_clients_clicked();

    void on_ajouter_client_clicked();

    void setFormulaire();
    void on_add_imageBtn_clicked();

    void on_modifier_client_clicked();
    void setQR();
    void on_search_client_button_clicked();

    void on_search_c_textChanged(const QString &arg1);
        void  on_refresh_clicked() ;
        void on_trier_client_clicked();

        void on_clearBtn_clicked();

        void on_google_search_button_clicked();

        void on_sms_clicked();

        void on_ardibutton_clicked();

private:
    Ui::MainWindow *ui;
    Employee E;
    QCamera *mCamera;
    QCameraViewfinder *mCameraViewfinder;
    QCameraImageCapture *mCameraImageCapture;
    QVBoxLayout *mLayout , *mlayout;
    QMenu *mOpcionesMenu;
    QAction *mEncenderAction;
    QAction *mApagarAction;
    QAction *mCapturarAction;
    Arduino A;
     document d;
    //QVector<double> qv_x, qv_y;
    //arduino
   // QByteArray data; //variable contenant les données reçus
    QString data;
    Dialog_stats *s;
    audience c;
    Salle X;
    Salle Etmp;
    Avocats tempavocat;
    QStringList files;
    /*******************************PRIVATE HAJER*************************************/
    QGraphicsView *mView;
    QGraphicsScene *mScene;
    QGraphicsTextItem *mText;
    QStringListModel *model;
    QCompleter *stringCompleter;
    QCompleter *ModelCompleter;
    SearchBox search;
    QSystemTrayIcon *notification;
  //  Arduino A;
    QByteArray dataled;
};

#endif // MAINWINDOW_H
