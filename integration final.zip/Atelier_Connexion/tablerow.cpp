#include "tablerow.h"
#include "client_fonctions.h"
tablerow::tablerow (QWidget *parent,QString CIN,QString NOM, QString prenom, QString age, QString machineimg){



    row_container->setGeometry(3,0,840,64); // ta3ti taille safa ta3 tableau
    row_container->setStyleSheet("background-color: white;\
                             border-top-left-radius: 15px;\
                             border-bottom-left-radius: 15px;\
                             border-top-right-radius: 15px;\
                             border-bottom-right-radius: 15px;\
                             color: #585856;\
");


   row_container->setMinimumHeight(64);// akal taille ynajem yekhdou
   row_container->setFixedHeight(80); // akber taille tnajem ta5oua el safa ta3 tableau

   img_label->setParent(row_container);
   img_label->setGeometry(0,0,121,64); //taille wel position mta3 limage

   QPixmap image (machineimg);
   img_label->setSizePolicy( QSizePolicy::Ignored, QSizePolicy::Ignored );
   image = image.scaled(121,80,Qt::IgnoreAspectRatio,Qt::FastTransformation);

   img_label->setPixmap(image);

   img_label->setMinimumHeight(64);

   nom_label->setParent(row_container);
   nom_label->setGeometry(120,0,121,64);
   nom_label->setText(NOM);
   nom_label->setStyleSheet("color: #585856;padding:6px;font: 63 10pt 'Montserrat SemiBold';");
   nom_label->setMinimumHeight(64); //taille wposition wloun mta3 safet el nom

   prenom_label->setParent(row_container);
   prenom_label->setGeometry(240,0,101,64);
   prenom_label->setText(prenom);
   prenom_label->setStyleSheet("color: #585856;padding:6px;font: 63 10pt 'Montserrat SemiBold';");
   prenom_label->setMinimumHeight(64);



   age_label->setParent(row_container);
   age_label->setGeometry(330,0,181,64);
   age_label->setText(age);
   age_label->setStyleSheet("color: #585856;padding:6px;font: 63 10pt 'Montserrat SemiBold';");
   age_label->setMinimumHeight(64);

   qrbtn->setObjectName("qrbutton");
   qrbtn->setParent(row_container);
   qrbtn->setGeometry(530,0,40,64);
   qrbtn->setStyleSheet("QPushButton {background-color: white;border:none;border-radius:15px;qproperty-icon: url(:/IMG/IMG/QRICON.png);qproperty-iconSize: 22px;}QPushButton::hover {background-color: #ffb3c1;}");
   qrbtn->setCursor(QCursor(Qt::PointingHandCursor));
   qrbtn->setWhatsThis(CIN);

   editBtn->setParent(row_container);
   editBtn->setGeometry(420,0,40,64);
   editBtn->setStyleSheet("QPushButton {background-color: white;border:none;border-radius:15px;qproperty-icon: url(:/IMG/IMG/editx-01.png);qproperty-iconSize: 29px;}QPushButton::hover {background-color: #ffb3c1;qproperty-iconSize: 18px;}");
   editBtn->setCursor(QCursor(Qt::PointingHandCursor));
   editBtn->setWhatsThis(CIN);
   editBtn->setWhatsThis(CIN);

   deleteBtn->setObjectName("deleteBtn");
   deleteBtn->setParent(row_container);
   deleteBtn->setGeometry(475,0,40,64);
   deleteBtn->setStyleSheet("QPushButton {background-color: white;border:none;border-radius:15px;qproperty-icon: url(:/IMG/IMG/trash-icon-01.png);qproperty-iconSize: 22px;}QPushButton::hover {background-color: #ffb3c1;}");
   deleteBtn->setCursor(QCursor(Qt::PointingHandCursor));
   deleteBtn->setWhatsThis(CIN);






  connect(deleteBtn, &QPushButton::clicked, this, &tablerow::deleteBtn_clicked);
  connect(editBtn, &QPushButton::clicked, this, &tablerow::updateBtn_clicked);
  connect(qrbtn, &QPushButton::clicked, this, &tablerow::qr_generator);














}
