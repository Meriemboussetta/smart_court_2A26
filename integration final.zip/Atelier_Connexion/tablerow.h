#ifndef TABLEROW_H
#define TABLEROW_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>

class tablerow : public QLabel
{

    Q_OBJECT


private slots:
    void deleteBtn_clicked(); // generation des clics sur bouttons supprimer , modifier
    void updateBtn_clicked();
    void qr_generator();
public:
    tablerow();
    explicit tablerow (QWidget *parent,QString CIN,QString NOM, QString prenom, QString age, QString machineimg);

    QLabel *row_container = new QLabel(this);
    QLabel *img_label = new QLabel();
    QLabel *nom_label = new QLabel();
    QLabel *prenom_label = new QLabel();
    QLabel *age_label = new QLabel();

    QPushButton *editBtn = new QPushButton();
    QPushButton *deleteBtn = new QPushButton(); // asna3li push button jdid
    QPushButton *qrbtn = new QPushButton();

    signals:
};

#endif // TABLEROW_H
