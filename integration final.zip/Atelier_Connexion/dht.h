#ifndef DHT_H
#define DHT_H


class dht
{
public:
    dht();
};

#endif // DHT_H
