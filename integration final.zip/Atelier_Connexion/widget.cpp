#include "widget.h"

Widget::Widget()
{

}
