#include "employee.h"
#include <QSqlQuery>
#include <QtDebug>
#include <QObject>
Employee::Employee()
{
id=0; nom=" "; prenom="";sexe="";date="";grade="";
}
Employee::Employee(int id,QString nom,QString prenom,QString date,QString sexe,QString grade)
{this->id=id;this->nom=nom;this->prenom=prenom;this->date=date;this->sexe=sexe;this->grade=grade;}
int Employee::getid(){return id;}
QString Employee::getnom(){return nom;}
QString Employee::getprenom(){return prenom;}
QString Employee::getsexe(){return sexe;}
QString Employee::getdate(){return date;}
QString Employee::getgrade(){return grade;}
void Employee::setid(int id){this->id=id;}
void Employee::setnom(QString nom){this->nom=nom;}
void Employee::setprenom(QString prenom){this->prenom=prenom;}
void Employee::setsexe(QString nom){this->sexe=nom;}
void Employee::setdate(QString nom){this->date=nom;}
void Employee::setgrade(QString nom){this->grade=nom;}


bool Employee::ajouter()
{


    QString id_string= QString::number(id);
     QSqlQuery query;
          query.prepare("INSERT INTO employee (id, nom, prenom,sexe,datee,grade) "
                        "VALUES (:id, :forename, :surname,:x,:y,:z)");
          query.bindValue(":id", id_string);
          query.bindValue(":forename", nom);
          query.bindValue(":surname", prenom);
          query.bindValue(":x", sexe);
          query.bindValue(":y", date);
          query.bindValue(":z", grade);

    return query.exec();
}
bool Employee::supprimer(int id)
{


    QSqlQuery query;
         query.prepare("Delete from employee where id=:id");
         query.bindValue(":id", id);

   return query.exec();


}
QSqlQueryModel* Employee::afficher()
{
  QSqlQueryModel* model=new QSqlQueryModel();


  model->setQuery("SELECT* FROM employee");
  model->setHeaderData(0, Qt::Horizontal, QObject::tr("Identifiant"));
  model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
  model->setHeaderData(2, Qt::Horizontal, QObject::tr("prenom"));
  model->setHeaderData(3, Qt::Horizontal, QObject::tr("sexe"));
  model->setHeaderData(4, Qt::Horizontal, QObject::tr("date"));
  model->setHeaderData(5, Qt::Horizontal, QObject::tr("grade"));


  return model;

}
bool Employee::modifier(int RID){
 QSqlQuery query;
      query.prepare("UPDATE employee SET id= :id, nom= :forename , prenom= :surname ,sexe= :x,datee= :y,grade= :z WHERE id= :RID ");
      query.bindValue(":RID", RID);
      query.bindValue(":id", id);
      query.bindValue(":forename", nom);
     query.bindValue(":surname", prenom);
      query.bindValue(":x", sexe);
       query.bindValue(":y", date);
        query.bindValue(":z", grade);

return query.exec();
}




