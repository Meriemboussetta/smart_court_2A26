#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include<QString>
#include<QSqlQueryModel>

class Employee
{
public:
    Employee();
    Employee(int,QString,QString,QString,QString,QString);
    int getid();
    QString getnom();
    QString getprenom();
    QString getsexe();
    QString getdate();
    QString getgrade();
    void setid(int);
    void setnom(QString);
    void setprenom(QString);
    void setsexe(QString);
    void setdate(QString);
    void setgrade(QString);
    bool ajouter();
    QSqlQueryModel* afficher();
    bool supprimer(int);
    bool modifier(int RID);
private:
    int id;
    QString nom, prenom,date,sexe,grade;
};

#endif // EMPLOYEE_H
