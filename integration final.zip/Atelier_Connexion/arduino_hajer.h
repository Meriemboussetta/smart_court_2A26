#ifndef ARDUINO_H
#define ARDUINO_H

#include <QDialog>
#include <QSerialPort>

namespace Ui {
class arduino_hajer;
}

class arduino_hajer : public QDialog
{
    Q_OBJECT

public:
    explicit arduino_hajer(QWidget *parent = nullptr);
    ~arduino_hajer();
private slots:
    void BacaSerial();
    void UpdateDataSensor(const QString);
   // void on_pushButton_clicked();
    void UpdateDataLed(const QString);

    void on_offbutton_clicked();

private:
    Ui::arduino_hajer *ui;

    QSerialPort *ard;
    static const quint16 vendor_id = 9025;
    static const quint16 produk_id = 67;
    QString port_name;
    bool ada_arduino;
    QByteArray dataserial;
    QString serialbuffer;
    QString serialbuffer2;
    QString serialbuffer3;
    QString serialbuffer4;
};

#endif // ARDUINO_H
