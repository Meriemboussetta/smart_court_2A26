#ifndef DOCUMENT_H
#define DOCUMENT_H
#include <QString>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QDoubleValidator>
#include <QtDebug>
#include <QObject>
#include <QMainWindow>
#include <QDateTime>
#include <QFile>
#include <QMessageBox>
#include<QTableView>
#include<QDesktopServices>
#include <qdesktopservices.h>


class document
{
public:
    document();
    document(int,QString,QString,QString);
    int getid();
    QString getnom();
    QString getprenom();
    QString getsujet_assise();

    void setid(int);
    void setnom(QString);
    void setprenom(QString);
    void setsujet_assise(QString);

    bool ajouter();
   bool test/*=false*/;
    QSqlQueryModel* afficher();
    bool supprimer(int);
    bool modifier();
    document recherche(int);
    void chercheID(QTableView *table, int CIN);
    void clearTable(QTableView *table);
       QSqlQueryModel* tri_id();
       QSqlQueryModel* tri_nom();
       QSqlQueryModel* tri_prenom();



private :
    int id;
    QString nom,prenom,sujet_assise;
};

#endif // DOCUMENT_H
