#include "dht.h"

dht::dht()
{

}
