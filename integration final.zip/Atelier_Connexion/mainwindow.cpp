#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "employee.h"
#include <QMessageBox>
#include <QIntValidator>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QDebug>
#include <QCamera>
#include <QCameraViewfinder>
#include <QCameraImageCapture>
#include <QVBoxLayout>
#include <QMenu>
#include <QAction>
#include <QFileDialog>
#include <QPdfWriter>
#include <QPainter>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QHorizontalStackedBarSeries>
#include <QtCharts/QLineSeries>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <QtWidgets/QMainWindow>
#include <QSettings>
#include "Arduino.h"

/*********************************************** INCLUDE MARIEM **********************************************/

#include <exportexcelobject.h>
#include "document.h"
#include "connection.h"

/**************************************INCLUDE CHI7I**********************************************************/
#include "audience.h"
#include<QDoubleValidator>
#include "QtPrintSupport"


/*****************************************INCLUDET RAYEN*******************************************************/
#include"salle.h"

/*******************************************INCLUDET OMAR ******************************************************/
#include "avocats.h"

#include <QtSql/QSqlError>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlDatabase>
#include "smtp.h"
#include <QDebug>
#include <QtPrintSupport/QPrinter>
#include <QtPrintSupport/QPrintDialog>
#include <QtPrintSupport/QtPrintSupport>
/*********************************************************INCLUDET HAJER *****************************/

#include"QStandardItemModel"
#include"qfilesystemmodel.h"
#include "QMessageBox"
#include"QToolTip"
#include"client_fonctions.h"
#include"QFileDialog"
#include"QTimer"
#include"tablerow.h"
#include"QVBoxLayout"
#include <fstream>
#include "qrcode.h"
#include <QtSvg/QSvgRenderer>
#include"tablerow.h"
#include <QUrl>
#include <QDesktopServices>
#include "sms.h"
#include "arduino_haj.h"


QT_CHARTS_USE_NAMESPACE




QString machineImg ="";
QTimer *timer = new QTimer();//setFormulaire
QTimer *timer2 = new QTimer();//refresh
QTimer *timer4 = new QTimer(); //stat
QTimer *timerP3 = new QTimer();
using qrcodegen::QrCode;
using qrcodegen::QrSegment;
int CIN = 0;

QVBoxLayout *layoutt = new QVBoxLayout();
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
int a=A.connect_arduino();
    ui->setupUi(this);
  //  setWindowFlags(Qt::Window | Qt::FramelessWindowHint);

    Arduino A;
    int ret=A.connect_arduino(); // lancer la connexion à arduino
    switch(ret){
    case(0):qDebug()<< "arduino is available and connected to : "<< A.getarduino_port_name();
        break;
    case(1):qDebug() << "arduino is available but not connected to :" <<A.getarduino_port_name();
       break;
    case(-1):qDebug() << "arduino is not available";
    }
     QObject::connect(A.getserial(),SIGNAL(readyRead()),this,SLOT(update_label())); // permet de lancer
   ui->id->setValidator( new QIntValidator(100, 9999999, this));
   ui->tab_employee->setModel(E.afficher());

   QSettings settings(QSettings::IniFormat, QSettings::UserScope,

                             QCoreApplication::organizationName(), QCoreApplication::applicationName());



          ui->WebBrowser->dynamicCall("Navigate(const QString&)", "https://www.google.com/maps/place/ESPRIT/@36.9016729,10.1713215,15z");


   mCamera = new QCamera(this);
   mCameraViewfinder = new QCameraViewfinder(this);
   mCameraImageCapture = new QCameraImageCapture(mCamera,this);
   mLayout = new QVBoxLayout;
   mOpcionesMenu = new QMenu ("Opciones",this);
   mEncenderAction =new QAction("ouvrire camera",this);
   mApagarAction =new QAction("prendre photo",this);
   mCapturarAction = new QAction("enregistrer",this);

   mOpcionesMenu->addActions({mEncenderAction,mApagarAction,
                             mCapturarAction});
   ui->pb_prendre_photo->setMenu(mOpcionesMenu);
   mCamera->setViewfinder(mCameraViewfinder);
   mLayout->addWidget(mCameraViewfinder);
   mLayout->setMargin(0);
   ui->scrollArea->setLayout(mLayout);

   connect(mEncenderAction, &QAction::triggered, [&](){
       mCamera->start();
   });
   connect(mApagarAction, &QAction::triggered, [&](){
       mCamera->stop();
   });
   connect(mCapturarAction, &QAction::triggered, [&](){
       auto filename=QFileDialog::getSaveFileName(this, "capturar","/",
                                                  "Imagen(*jpg;*jpeg)");
       if(filename.isEmpty()){
           return ;
       }
       mCameraImageCapture->setCaptureDestination(
                   QCameraImageCapture::CaptureToFile);
       QImageEncoderSettings ImageEncoderSettings;
       ImageEncoderSettings.setCodec("image/jpeg");
       ImageEncoderSettings.setResolution(1600,1200);
       mCameraImageCapture->setEncodingSettings(ImageEncoderSettings);
       mCamera->setCaptureMode(QCamera::CaptureStillImage);
       mCamera->start();
       mCamera->searchAndLock();
       mCameraImageCapture->capture(filename);
       mCamera->unlock();
});


                        /************************ INIT MARIEM**************************/

   ui->id_mariem->setValidator( new QIntValidator(100, 9999999, this));
   ui->tab_document_mariem->setModel(d.afficher());
   //stat
   QPieSeries *series=new QPieSeries();
     series->append("violence",500);
     series->append("",1000);
     series->append("ilyes",3000);
     series->append("habiba",500);
     series->append("fafa",5000);

     series->setLabelsVisible(true);
     series->setLabelsPosition(QPieSlice::LabelInsideHorizontal);

     for(auto slice : series->slices())
        slice->setLabel(QString("%1%").arg(100*slice->percentage(), 0, 'f', 1));

     QChart *chart=new QChart();
     chart->addSeries(series);
     chart->setTitle("participation partenaire");

     QChartView *chartview=new QChartView(chart);
   //  chartview->setParent(ui->horizontalframe);


     /*************************INIT CHI7I ********************************************/

     ui->le_cin_chi7i->setValidator(new QIntValidator(0,999999,this));
     QDate ladat=QDate::currentDate();
     QString datee=ladat.toString();


     /*****************************************INIT HAJER *********************************/

     ui->CIN->setValidator(new QIntValidator(0,9999999,this)); // cntrol saisie
 //    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);


       //  ui->listWidget->addItem(new QListWidgetItem(QIcon(":/res/icon"), ""));
     ui->scrollArea_hajer->setWidget( ui->scrollAreaWidgetContents_2 );
     ui->scrollAreaWidgetContents_2 ->setLayout( layoutt );            // ==========> y5alik tescorli wa9tli tajouti barcha hajet
     connect(timer, SIGNAL(timeout()), this, SLOT(setFormulaire()));
     connect(timerP3, SIGNAL(timeout()), this, SLOT(setQR()));
     connect(timer2, SIGNAL(timeout()), this, SLOT(on_refresh_clicked()));
     timer2->start(100);

     ui->client_combo->addItem("par défaut");
         ui->client_combo->addItem("nom");
         ui->client_combo->addItem("prenom");
         ui->client_combo->addItem("age");

       //  ui->prog->setValue(0);



 notification = new QSystemTrayIcon(this) ;


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_ajouter_clicked()
{
    int id=ui->id->text().toInt();
    QString nom=ui->nom->text();
    QString prenom=ui->prenom->text();
    //Employee E(id,nom,prenom);
    QString sexe=ui->sexe_in->currentText();
    QString date=ui->date_in->text();
    QString grade=ui->grad_in->currentText();
    Employee E(id,nom,prenom,sexe,date,grade);

    bool test=E.ajouter();
        if ( test)
        {QMessageBox::information(nullptr, QObject::tr("OK"),
                                QObject::tr("Ajout effectué.\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);
        ui->tab_employee->setModel(E.afficher());}


                else
                    QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                                QObject::tr("Ajout non effectué.\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_supprimer_clicked()
{
    Employee E1; E1.setid(ui->id_supp->text().toInt());
    bool test=E1.supprimer(E1.getid());
   { QMessageBox::information(nullptr, QObject::tr("OK"),
                                    QObject::tr("suppression effectué.\n"
                                                "Click Cancel to exit."), QMessageBox::Cancel);}
if (test){
    QObject::tr("suppression effectué.\n");
    ui->tab_employee->setModel(E.afficher());



}

    else
        QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                    QObject::tr("Ajout non effectué.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_pushButton_clicked()
{
    int id=ui->lineEdit->text().toInt();
    QString nom=ui->lineEdit_2->text();
    QString prenom=ui->lineEdit_3->text();
    int Rid=ui->lineEdit_4->text().toInt();
    QString sexe=ui->sexe_in_2->currentText();
    QString date=ui->date_in_2->text();
    QString grade=ui->grad_in_2->currentText();
     Employee E(id,nom,prenom,sexe,date,grade);
    bool test=E.modifier(Rid);
        if (test)
        {QMessageBox::information(nullptr, QObject::tr("OK"),
                                QObject::tr("modification effectué.\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);
        ui->tab_employee->setModel(E.afficher());}


                else
                    QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                                QObject::tr("modification non effectué.\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_pushButton_chercher_clicked()
{
    QString val=ui->lineEdit_chercher->text();
        QSqlQuery query;
        QSqlQueryModel * model=new QSqlQueryModel();

        /*model->setHeaderData(0, Qt::Horizontal, QObject::tr("Identifiant"));
        model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
        model->setHeaderData(2, Qt::Horizontal, QObject::tr("prenom"));
        model->setHeaderData(3, Qt::Horizontal, QObject::tr("sexe"));
        model->setHeaderData(4, Qt::Horizontal, QObject::tr("date"));
        model->setHeaderData(5, Qt::Horizontal, QObject::tr("grade"));*/

         model->setQuery("select sexe,datee,grade from employee where id= " +val+" ;");

        QString sexe=model->data(model->index(0,1)).toString();

        QString date=model->data(model->index(0,0)).toString();
        QString grade=model->data(model->index(0,2)).toString();
        model->setHeaderData(0, Qt::Horizontal, QObject::tr("Date"));
        model->setHeaderData(1, Qt::Horizontal, QObject::tr("Sexe"));
        model->setHeaderData(2, Qt::Horizontal, QObject::tr("Grade"));

    ui->tab_employee_2->setModel(model);
        /*query.prepare("select * from employee where id= :id or nom=:nom or prenom=:prenom ");
        query.bindValue(":id",val);
        query.bindValue(":nom",val);
        query.bindValue(":prenom",val);

        if(query.exec()){

            while(query.next()){*/
         model->setQuery("select * from employee where id= " +val+" ;");
                ui->lineEdit_5->setText(model->data(model->index(0,0)).toString());
                ui->lineEdit_6->setText(model->data(model->index(0,1)).toString());
                ui->lineEdit_7->setText(model->data(model->index(0,2)).toString());



}

void MainWindow::on_tabWidget_currentChanged(int index)
{
ui->tab_employee->setModel(E.afficher());
}

void MainWindow::on_tri_id_clicked()
{
    QSqlQueryModel *model=new QSqlQueryModel();
        model->setQuery("select * from employee order by ID;");
        model->setHeaderData(0, Qt::Horizontal,QObject:: tr("id"));
        model->setHeaderData(1, Qt::Horizontal, QObject:: tr("nom"));
          model->setHeaderData(2, Qt::Horizontal, QObject:: tr("prenom"));
           model->setHeaderData(3, Qt::Horizontal, QObject:: tr("sexe"));
            model->setHeaderData(4, Qt::Horizontal, QObject:: tr("date"));
            model->setHeaderData(4, Qt::Horizontal, QObject:: tr("grade"));
             ui->tab_employee->setModel(model);



}

void MainWindow::on_tri_date_clicked()
{
    QSqlQueryModel *model=new QSqlQueryModel();
        model->setQuery("select * from employee order by datee;");
        model->setHeaderData(0, Qt::Horizontal,QObject:: tr("id"));
        model->setHeaderData(1, Qt::Horizontal, QObject:: tr("nom"));
          model->setHeaderData(2, Qt::Horizontal, QObject:: tr("prenom"));
           model->setHeaderData(3, Qt::Horizontal, QObject:: tr("sexe"));
            model->setHeaderData(4, Qt::Horizontal, QObject:: tr("date"));
            model->setHeaderData(4, Qt::Horizontal, QObject:: tr("grade"));
             ui->tab_employee->setModel(model);
}

void MainWindow::on_pushButton_2_clicked()
{
    int CIN = ui->id->text().toInt();

       QString filename("C:\\Users\\USER\\Desktop\\qtTryouts\\tryout1\\pdf");
       QPdfWriter pdf("C:/Users/khali/Desktop/qt/Atelier_Connexion/exemple.pdf");
       QPainter painter(&pdf);


                   painter.setPen(Qt::blue);
                   painter.setFont(QFont("Arial", 30));
                   painter.drawText(1100,1200,"Documentation d'un employee");
                   painter.setPen(Qt::black);
                  // painter.setFont(QFont("Arial", 15));

                   painter.drawRect(100,100,7300,2600);
                   painter.setFont(QFont("Arial", 9));
                   painter.drawText(200,3300,"CIN: ");
                   painter.drawText(1200,3300,"Nom: ");
                   painter.drawText(2200,3300,"Prenom: ");
                   painter.drawText(3200,3300,"sexe: ");
                   painter.drawText(4200,3300,"Date de naissance: ");
                   painter.drawText(5500,3300,"grade: ");


                   QSqlQuery query;
                   query.prepare("select * from employee ;");
                  // query.bindValue(":CIN",CIN);
                   query.exec(); int i=3500;
                   while (query.next())
                   {
                       painter.drawText(200,i,query.value(0).toString());
                       painter.drawText(1200,i,query.value(1).toString());
                       painter.drawText(2200,i,query.value(2).toString());
                       painter.drawText(3200,i,query.value(3).toString());
                       painter.drawText(4200,i,query.value(4).toString());
                       painter.drawText(5200,i,query.value(5).toString());
i+=500;

                   }
                   /*QPrintPreviewDialog *printPreview = new QPrintPreviewDialog();
                       connect(printPreview, SIGNAL(paintRequested(QPrinter*)), this, SLOT(print(QPrinter*)));

                       printPreview->setWindowTitle("Preview Dialog");
                       Qt::WindowFlags flags(Qt::WindowTitleHint);
                       printPreview->setWindowFlags(flags);
                       printPreview->exec();
                QPrinter *p=new QPrinter();
                QPrintDialog dialog(p,this);
                   dialog.exec();*/

}

void MainWindow::on_pushButton_stat_clicked()
{
    QSqlQuery query0,query1,query2,query3;
       float valjuge=0,valpolicier=0,valautre=0,items=0;
       query0.prepare("select * from employee");
       query0.exec();
       query1.prepare("select * from employee where grade = :juge  ");
       query1.bindValue(":juge","juge");
       query1.exec();
       query2.prepare("select * from employee where grade = :Policier  ");
       query2.bindValue(":policier","policier");
       query2.exec();
       query3.prepare("select * from employee where grade = :autre  ");
       query3.bindValue(":autre","autre");
       query3.exec();


       while(query0.next()){items++;};
       while(query1.next()){valjuge++;};
       while(query2.next()){valpolicier++;};
       while(query3.next()){valautre++;};


       valjuge=valjuge/items;
       valpolicier=valpolicier/items;
       valautre=valautre/items;

       QPieSeries *series = new QPieSeries();
       series->append("juge",valjuge);
       series->append("policier",valpolicier);
       series->append("autre",valautre);


       QPieSlice *slice0 = series->slices().at(0);
       slice0->setLabelVisible();
       QPieSlice *slice1 = series->slices().at(1);
       slice1->setLabelVisible();
       QPieSlice *slice2 = series->slices().at(2);
       slice2->setLabelVisible();
      /* QPieSlice *slice3 = series->slices().at(3);
       slice3->setLabelVisible();
       QPieSlice *slice4 = series->slices().at(4);
       slice4->setLabelVisible();
       QPieSlice *slice5 = series->slices().at(5);
       slice5->setLabelVisible();*/

       QChart *chart = new QChart();
       chart->addSeries(series);
       chart->legend()->hide();

       QChartView *chartView = new QChartView(chart,this);
       chartView->setRenderHint(QPainter::Antialiasing);
       chartView->setMinimumSize(420,300);
       chartView->show();
}

void MainWindow::on_pushButton_3_clicked()
{ QString x;
   x=A.read_from_arduino();
   if(x=="+")
       ui->etat->setText("Ouvert");
   else if (x=="-")
       ui->etat->setText("Fermer");

}

void MainWindow::on_pb_prendre_photo_clicked()
{

}





/***********************************Main MARIEM**************************************************/

void MainWindow::on_ajouter_mariem_clicked()
{
    bool test=true;
        int id =ui->id_mariem->text().toInt();
           QString nom =ui->nom__mariem->text();
           QString prenom =ui->prenom_mariem->text();
           QString sujet_assise =ui->sujet_mariem->text();
           document d(id ,nom,prenom,sujet_assise);
          test= d.ajouter();
        //bool test=d.ajouter();

    if(test)
     {
        ui->tab_document_mariem->setModel(d.afficher());

        QMessageBox::information(nullptr, QObject::tr("ok"),
                    QObject::tr("ajout successful.\n"
                                "ajout effectuer."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("nope"),
                       QObject::tr("connection failed.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}


void MainWindow::on_recherche_mariem_clicked()
{
    document d;
    QString text;
        d.clearTable(ui->tab_document_mariem);
        int id=ui->id_recherche_mariem->text().toInt();
        d.chercheID(ui->tab_document_mariem,id);
}

void MainWindow::on_tri_id_mariem_clicked()
{
    QMessageBox::information(nullptr, QObject::tr("Ok"),
             QObject::tr("tri effectué.\n"
                         "Click Cancel to exit."), QMessageBox::Cancel);
            ui->tab_document_mariem->setModel(d.tri_id());
}

void MainWindow::on_tri_nom_mariem_clicked()
{
    QMessageBox::information(nullptr, QObject::tr("Ok"),
             QObject::tr("tri effectué.\n"
                         "Click Cancel to exit."), QMessageBox::Cancel);
            ui->tab_document_mariem->setModel(d.tri_nom());
}

void MainWindow::on_tri_prenom_mariem_clicked()
{
    QMessageBox::information(nullptr, QObject::tr("Ok"),
             QObject::tr("tri effectué.\n"
                         "Click Cancel to exit."), QMessageBox::Cancel);
            ui->tab_document_mariem->setModel(d.tri_prenom());
}

void MainWindow::on_pdf_mariem_clicked()
{
    QPdfWriter pdf("C:/Users/Mariem/Desktop/essaie/meriem.pdf");

               QPainter painter(&pdf);
               int i = 4000;
                      painter.setPen(Qt::darkCyan);
                      painter.setFont(QFont("Time New Roman", 25));
                      painter.drawText(3000,1400,"Document");
                      painter.setPen(Qt::black);
                      painter.setFont(QFont("Time New Roman", 15));
                      painter.drawRect(100,100,9400,2500);
                      painter.drawRect(100,3000,9400,500);
                      painter.setFont(QFont("Time New Roman", 9));
                      painter.drawText(400,3300,"id");
                      painter.drawText(1350,3300,"nom");
                      painter.drawText(2200,3300,"prenom");
                      painter.drawText(3400,3300,"sujet_assise");


                      painter.drawRect(100,3000,9400,9000);

                      QSqlQuery query;
                      query.prepare("select * from DOCUMENT");
                      query.exec();
                      while (query.next())
                      {

                          painter.drawText(1350,i,query.value(1).toString());
                          painter.drawText(2300,i,query.value(2).toString());
                          painter.drawText(3400,i,query.value(3).toString());
                          painter.drawText(4400,i,query.value(4).toString());





                         i = i + 350;
                      }
                      QMessageBox::information(this, QObject::tr("PDF Saved Successfuly!"),
                      QObject::tr("PDF Saved Successfuly!.\n" "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_insertimg_mariem_clicked()
{
    QString filename = QFileDialog::getSaveFileName(this,tr("choose"),"",tr("Image(*.png *.jpeg *.jpg *.bmp *.gif)"));
    QSqlQuery query;
          query.prepare("INSERT INTO IMAGE (IMG) "
                        "VALUES (:LOAD_FILE(filename))");
          query.bindValue(":LOAD_FILE(filename)",  filename);
          //QLabel* x = ui->imagee;
          //x->text();
          //x->(filename);
if (QString::compare(filename,QString()) !=0)
      {
          QImage image;
          bool valid = image.load(filename);
          if(valid)
          {
              image=image.scaledToWidth(ui->imagee->width(), Qt::SmoothTransformation);
                      ui->imagee->setPixmap(QPixmap::fromImage(image));
                      query.exec();
          }
          else
          {
              //ERROR HANDLING
          }
      }
}

void MainWindow::on_excel_mariem_clicked()
{
    QString fileName = QFileDialog::getSaveFileName(this, tr("Excel file"), qApp->applicationDirPath (),
                                                    tr("Excel Files (*.xls)"));
    if (fileName.isEmpty())
        return;

    ExportExcelObject obj(fileName, "mydata", ui->tab_document_mariem);

    //colums to export
    obj.addField(0, "entier", "char(20)");
    obj.addField(1, "reel", "char(20)");
    obj.addField(2, "combobox", "char(20)");
    obj.addField(3, "lineedit", "char(20)");
    obj.addField(4, "textedit", "char(20)");
    obj.addField(5, "dateedit", "char(20)");
    obj.addField(5, "timeedit", "char(20)");


    int retVal = obj.export2Excel();
    if( retVal > 0)
    {
        QMessageBox::information(this, tr("Done"),
                                 QString(tr("%1 records exported!")).arg(retVal)
                                 );
    }
}



void MainWindow::on_stat_mariem_clicked()
{
    s = new Dialog_stats();

  s->setWindowTitle("statistique ComboBox");
  s->choix_pie();
  s->show();
}

void MainWindow::on_pb_supp_mariem_clicked()
{
    document d;
    d.setid(ui->le_idsupp_mariem->text().toInt());
    bool test=d.supprimer(d.getid());
    if(test){
        QMessageBox::information(nullptr, QObject::tr("ok"),
                    QObject::tr("suppresion successful.\n"
                                "suppresion effectuer."), QMessageBox::Cancel);
    ui->tab_document_mariem->setModel(d.afficher());
    }
    else
        QMessageBox::critical(nullptr, QObject::tr("nope"),
                    QObject::tr("suppresion failed.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_modifier_mariem_1_clicked()
{

    int ID_Document=ui->id_mod_mariem->text().toInt();
    QString nom=ui->nom_mod_mariem->text();
    QString prenom=ui->prenom_mariem_2->text();
    QString sujet_assise=ui->sujet_mod_mariem->text();
    document d(ID_Document,nom,prenom,sujet_assise);
       bool test=d.modifier();
       if(test)
       { ui->tab_document_mariem->setModel(d.afficher());
           QMessageBox::information(nullptr, QObject::tr("ok"),
                                QObject::tr("Modiffication effectué"),QMessageBox::Cancel);
       }
       else
           QMessageBox::critical(nullptr, QObject::tr("not ok"),
                                QObject::tr("Modiffication non effectué"),QMessageBox::Cancel);
}

void MainWindow::on_update_label_linkActivated_clicked()
{
    data=A.read_from_arduino();
    if(data=="v")
    {QMessageBox::information(nullptr,QObject::tr("ok"),QObject::tr("porte  ouverte\n ""click cancel"),QMessageBox::Cancel);
     qDebug()<<data;
    }
    if(data=="n")
    {
    QMessageBox::information(nullptr,QObject::tr("ok"),QObject::tr("porte non  ouverte\n ""click cancel"),QMessageBox::Cancel);
    qDebug()<<data;
    }
}

void MainWindow::on_connect_mariem_clicked()
{
    Connection c;
    QString tem;
     c.createconnect();
    QSqlQueryModel model;
    QString at=A.read_from_arduino();
    QSqlQuery query;
    tem="warm";
    query.prepare("INSERT INTO DOCUMENT (TEM) "
                   "VALUES (:tem);");
    query.bindValue(":temperature", tem);
}




/******************************************************MAIN CHI7I*************************************************/

void MainWindow::on_Gestion_audience_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
    ui->Gestion_audience->setCheckable(true);
    ui->gestion_employee_2->setCheckable(false);
    ui->gestion_documents->setCheckable(false);
    ui->Gestion_des_clients->setCheckable(false);
    ui->Gestion_des_Salle->setCheckable(false);
    ui->Gestion_des_avocats->setCheckable(false);



    ui->Gestion_audience->setChecked(true);
}

void MainWindow::on_trie_chi7i_clicked()
{
    audience p;
     ui->table_aud_chi7i->setModel(p.tri_cin());
    QMessageBox::information(nullptr, QObject::tr("Ok"),
         QObject::tr("tri effectué.\n"
                     "Click Cancel to exit."), QMessageBox::Cancel);
        ui->table_aud_chi7i->setModel(p.tri_cin());
}

void MainWindow::on_stats_chi7i_clicked()
{
    QSqlQueryModel * model= new QSqlQueryModel();
        model->setQuery("select * from AUDIENCE where NBR_JURES > 1");
        float dispo1=model->rowCount();

        model->setQuery("select * from AUDIENCE where NBR_JURES <= 1");
        float dispo=model->rowCount();

        float total=dispo1+dispo;
            QString a=QString(" beaucoup de juges. " +QString::number((dispo1*100)/total,'f',2)+"%" );
            QString b=QString(" un seul juge.  "+QString::number((dispo*100)/total,'f',2)+"%" );
            QPieSeries *series = new QPieSeries();
            series->append(a,dispo1);
            series->append(b,dispo);
        if (dispo1!=0)
        {QPieSlice *slice = series->slices().at(0);
            slice->setLabelVisible();
            slice->setPen(QPen());}
        if ( dispo!=0)
        {
            QPieSlice *slice1 = series->slices().at(1);
            slice1->setLabelVisible();
        }

        QChart *chart = new QChart();

        chart->addSeries(series);
        chart->setTitle("nombre de jures sous demande: "+ QString::number(total));
        chart->legend()->hide();

        QChartView *chartView = new QChartView(chart);
        chartView->setRenderHint(QPainter::Antialiasing);
        chartView->resize(1000,500);
        chartView->show();
}

void MainWindow::on_pdf_chi7i_clicked()
{
    QSqlDatabase db;

                QTableView tableView;
                QSqlQueryModel * Modal=new  QSqlQueryModel();

                QSqlQuery qry;
                 qry.prepare("SELECT* FROM AUDIENCE");
                 qry.exec();
                 Modal->setQuery(qry);
                 tableView.setModel(Modal);

                 db.close();

                 QString strStream;
                 QTextStream out(&strStream);

                 const int rowCount = tableView.model()->rowCount();
                 const int columnCount =  tableView.model()->columnCount();

                 const QString strTitle ="Listes des procès";

                 out <<  "<html>\n"
                         "<img src='C:/Users/ASUS/Desktop/Smart Parc/SmartParc.png' height='155' width='140'/>"
                     "<head>\n"
                         "<meta Content=\"Text/html; charset=Windows-1251\">\n"
                     <<  QString("<title>%1</title>\n").arg(strTitle)
                     <<  "</head>\n"
                     "<body bgcolor=#ffffff link=#5000A0>\n"
                    << QString("<h3 style=\" font-size: 50px; font-family: Arial, Helvetica, sans-serif; color: #e80e32; font-weight: lighter; text-align: center;\">%1</h3>\n").arg("LISTE DES PROCES")
                    <<"<br>"

                    <<"<table border=1 cellspacing=0 cellpadding=2 width=\"100%\">\n";
                 out << "<thead><tr bgcolor=#f0f0f0>";
                 for (int column = 0; column < columnCount; column++)
                     if (!tableView.isColumnHidden(column))
                         out << QString("<th>%1</th>").arg(tableView.model()->headerData(column, Qt::Horizontal).toString());
                 out << "</tr></thead>\n";

                 for (int row = 0; row < rowCount; row++)
                 {
                     out << "<tr>";
                     for (int column = 0; column < columnCount; column++)
                     {
                         if (!tableView.isColumnHidden(column))
                         {
                             QString data = tableView.model()->data(tableView.model()->index(row, column)).toString().simplified();
                             out << QString("<td bkcolor=0>%1</td>").arg((!data.isEmpty()) ? data : QString("&nbsp;"));
                         }
                     }
                     out << "</tr>\n";
                 }
                 out <<  "</table>\n"
                         "<br><br>"
                         <<"<br>"
                         <<"<table border=1 cellspacing=0 cellpadding=2>\n";

                     out << "<thead><tr bgcolor=#f0f0f0>";

                         out <<  "</table>\n"

                     "</body>\n"
                     "</html>\n";

                 QTextDocument *ListeDesproces = new QTextDocument();
                 ListeDesproces->setHtml(strStream);

                 QPrinter printer;
                 QPrintDialog *dialog = new QPrintDialog(&printer, NULL);
                 if (dialog->exec() == QDialog::Accepted)
                 {

                     ListeDesproces->print(&printer);
                 }
                 printer.setOutputFormat(QPrinter::PdfFormat);
                 printer.setPaperSize(QPrinter::A4);
                 printer.setOutputFileName("/tmp/Produit.pdf");
                 printer.setPageMargins(QMarginsF(15, 15, 15, 15));

                 delete ListeDesproces;
}

void MainWindow::on_radioButton_chi7i_clicked()
{
    audience A;
     QSqlQueryModel* model=new QSqlQueryModel();
 A.geo();
}

void MainWindow::on_ajouter_chi7i_clicked()
{
    QString cin=ui->le_cin_chi7i->text();
    QString nom=ui->le_nom_chi7i->text();
    QString prenom=ui->le_prenom_chi7i->text();
    int nbr_jures=ui->le_nbr_chi7i->text().toInt();
    int personnes=ui->le_personnes_chi7i->text().toInt();
    QString date_auj;
    audience a(cin, prenom, nom, nbr_jures, personnes,date_auj);
    bool test=a.ajouter();
    QMessageBox msgBox;
    if(test)
           {
           msgBox.setText("ajout avec succes.");
           ui->table_aud_chi7i->setModel(a.afficher());}
           else
                msgBox.setText("echec d'ajout");
                msgBox.exec();
}


void MainWindow::on_modifer_mod_chi7i_clicked()
{
    audience a;
       QString cin=ui->cinedit_mod_chi7i->text();
        QString nom=ui->nomedit_mod_chi7i->text();
         QString prenom=ui->prenomedit_mod_chi7i->text();
          int nbr_jures=ui->nbrjuresedit_mod_chi7i->text().toInt();
          int personnes=ui->personnesedit_mod_chi7i->text().toInt();
          QString date_auj;

          audience c(cin, prenom, nom, nbr_jures, personnes,date_auj);

       bool test=c.modifier();

       QMessageBox msgBox;
       if(test)
       {
       msgBox.setText("modification avec succes.");
       ui->table_aud_chi7i->setModel(c.afficher());}
       else

            msgBox.setText("echec de modification");
            msgBox.exec();
}

void MainWindow::on_supprimer_chi7i_clicked()
{
    audience a1;
    a1.setcin(ui->sup_cin_chi7i->text());
    bool test=a1.supprimer(a1.get_cin());
    QMessageBox msgBox;
    if(test)
    {
    msgBox.setText("supression avec succes.");
    ui->table_aud_chi7i->setModel(c.afficher());}
    else
         msgBox.setText("echec de supression");
         msgBox.exec();
}

void MainWindow::on_image_chi7i_clicked()
{
    QString filename= QFileDialog::getOpenFileName(this,tr("CHOOSE"),"",tr("Images(*.png *.jpg *.jpeg *.bmp *.gif)"));
    if(QString::compare(filename,QString())!=0)
    {
        QImage image;
        bool valid = image.load(filename);
        if(valid)
        {
            image= image.scaledToWidth(ui->IMG_Added_chi7i->width(), Qt::SmoothTransformation);
            image= image.scaledToHeight(ui->IMG_Added_chi7i->height(), Qt::SmoothTransformation);
            ui->IMG_Added_chi7i->setPixmap(QPixmap::fromImage(image));
        }
        else
        {
            QMessageBox::critical(nullptr, QObject::tr("ERROR"),
            QObject::tr("Add Failed !"), QMessageBox::Ok);
        }
    }
}

void MainWindow::on_ok_chi7i_textChanged(const QString &arg1)
{
    audience a;
        QString rech=ui->ok_chi7i->text();
        ui->tab_re_chi7i->setModel(a.recherche(rech));
}



/***************************************************************** MAIN RAYEN ****************************************************/





void MainWindow::on_Gestion_des_Salle_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
    ui->Gestion_des_Salle->setCheckable(true);
    ui->gestion_employee_2->setCheckable(false);
    ui->Gestion_des_avocats->setCheckable(false);

    ui->Gestion_audience->setCheckable(false);
    ui->gestion_documents->setCheckable(false);
    ui->Gestion_des_clients->setCheckable(false);


    ui->Gestion_des_Salle->setChecked(true);
}

void MainWindow::on_ajouter_rayen_clicked()
{
    int num=ui->num_rayen->text().toInt();
    QString loc=ui->loc_rayen->text();
    int heurd=ui->heurd_rayen->text().toInt();
    int heurf=ui->heurf_rayen->text().toInt();
    Salle X(num,loc,heurd,heurf);
    bool test=X.ajouter();

 if(test)
 {
     ui->tab_salle_rayen->setModel(X.afficher());
     ui->list_rayen->setModel(X.Horloge());
     ui->time_rayen->setModel(X.Timetable());

     QMessageBox::information(nullptr, QObject::tr("ok"),
                     QObject::tr("Ajouter effectué.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
 }

 else
     QMessageBox::critical(nullptr, QObject::tr("erreur"),
                    QObject::tr("Ajouter non  effectué.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_supprimer_rayen_clicked()
{
    Salle Etmp; Etmp.setnum (ui->num_sup_rayen ->text().toInt());
    bool test=Etmp.supprimer(Etmp.getnum());
    if(test)
    {
       QMessageBox::information(nullptr,QObject::tr("ok"),
                                QObject::tr("suppression effectuee \n"
                                            "click Cancel to exit."), QMessageBox::Cancel);
    }
    else
        QMessageBox::critical(nullptr,QObject::tr("erreur"),
                               QObject::tr("suppression non effectuee.\n"
                                      "click Cancel to exit."),QMessageBox::Cancel);
}

void MainWindow::on_affichierstat_clicked()
{
    QBarSet *set0 = new QBarSet("");


    *set0 << 1 << 2 << 3 << 4 << 5 << 4;

//![1]

//![2]
    QBarSeries *series = new QBarSeries();
    series->append(set0);


//![2]

//![3]
    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("heures pour chaque salle");
    chart->setAnimationOptions(QChart::SeriesAnimations);
//![3]

//![4]
    QStringList categories;
    categories << "Jan" << "Feb" << "Mar" << "Apr" << "May" << "Jun";
    QBarCategoryAxis *axis = new QBarCategoryAxis();
    axis->append(categories);
    chart->createDefaultAxes();
    chart->setAxisX(axis, series);
//![4]

//![5]
    chart->legend()->setVisible(true);
    chart->legend()->setAlignment(Qt::AlignBottom);
//![5]

//![6]
    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
//![6]

//![7]
    QMainWindow window;
    window.setCentralWidget(chartView);
    window.resize(420, 300);
    window.show();
//![7]


}

void MainWindow::on_searchbutton_rayen_clicked()
{
    QMessageBox::information(nullptr, QObject::tr("Ok"),

             QObject::tr("tri effectué.\n"

                         "Click Cancel to exit."), QMessageBox::Cancel);

            ui->tab_salle_rayen->setModel(X.tri_num());
}

void MainWindow::on_modifier_clicked()
{
    Salle X;
       int num=ui->nouv_num_mod->text().toInt();
         QString loc=ui->localisation_mod->text();
          int heurd=ui->heured_rayen->text().toInt();
          int heurf=ui->heurf_rayen_mod->text().toInt();
          int Rid=ui->num_mod_rayen->text().toInt();

          Salle S(num, loc, heurd, heurf);

       bool test=S.modifier(Rid);

       QMessageBox msgBox;
       if(test)
       {
       msgBox.setText("modification avec succes.");
       ui->tab_salle_rayen->setModel(X.afficher());}
       else

            msgBox.setText("echec de modification");
            msgBox.exec();

}

/***************************************************MAIN OMAR ***************************************/

void MainWindow::on_buttonBox_Avocats_accepted()
{
    QString CIN = ui->lineEdit_cin_A->text();
    QString Nom = ui->lineEdit_nom_A->text();
    QString Prenom = ui->lineEdit_prenom_A->text();
    QString Mail = ui->lineEdit_mail_A->text();
    QString Tel = ui->lineEdit_tel_A->text();
    QString Salaire = ui->lineEdit_salaire_A->text();


 Avocats C(CIN,Nom,Prenom,Mail,Tel,Salaire);
    bool test = C.ajouteravocat();
    if(test)
    {
        QMessageBox::information(nullptr, QObject::tr("OK"),
                                 QObject::tr("Ajout effectuer\n"
                                             "Click Cancel to exit."), QMessageBox::Cancel);
        ui->tableView_avocats->setModel(tempavocat.afficheravocat());
        ui->lineEdit_cin_m->clear();
        ui->lineEdit_nom_4->clear();
        ui->lineEdit_prenom_m->clear();
        ui->lineEdit_mail_m->clear();
        ui->lineEdit_tel_m->clear();
        ui->lineEdit_salaire_m->clear();




    }else{
        QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                                 QObject::tr("Ajout non effectuer\n"
                                             "Click Cancel to exit."), QMessageBox::Cancel); }
}

void MainWindow::on_buttonBox_2Avocats_accepted()
{
    QString CIN = ui->lineEdit_cin_m->text();
    QString Nom = ui->lineEdit_nom_4->text();
    QString Prenom = ui->lineEdit_prenom_m->text();
    QString Mail = ui->lineEdit_mail_m->text();
    QString Tel = ui->lineEdit_tel_m->text();
    QString Salaire= ui->lineEdit_salaire_m->text();



    Avocats C(CIN,Nom,Prenom,Mail,Tel,Salaire);
     bool test=C.modifieravocat(CIN,Nom,Prenom,Mail,Tel,Salaire);
    if(test)
    {
        QMessageBox::information(nullptr, QObject::tr("Modifier une reservationt !"),
                                 QObject::tr(" reservation modifiée ! \n"
                                             "Click Cancel to exit."), QMessageBox::Cancel);
        ui->tableView_avocats->setModel(tempavocat.afficheravocat());
        ui->lineEdit_cin_m->clear();
        ui->lineEdit_nom_4->clear();
        ui->lineEdit_prenom_m->clear();
        ui->lineEdit_mail_m->clear();
        ui->lineEdit_tel_m->clear();
        ui->lineEdit_salaire_m->clear();
    }

    else {

        QMessageBox::critical(nullptr, QObject::tr("Modifier Reservation"),
                              QObject::tr("Erreur !.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
    }
}

void MainWindow::on_buttonBox_A_accepted()
{
    QString CIN = ui->lineEdit_cin_s->text();
    Avocats temp;

    bool test=temp.supprimeravocat(CIN);
    if(test)
    {
        QMessageBox::information(nullptr, QObject::tr("OK"),
                                 QObject::tr("Suppression effectuer\n"
                                             "Click Cancel to exit."), QMessageBox::Cancel);
    }else{
        QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                                 QObject::tr("Suppresion non effectuer\n"
                                             "Click Cancel to exit."), QMessageBox::Cancel);
}
}

void MainWindow::on_pushButton_listeres_clicked()
{
    ui->tableView_avocats->setModel(tempavocat.afficheravocat());

}

void MainWindow::on_radioButton_tricin_2_clicked()
{
    Connection conn;
    QSqlQueryModel * model = new QSqlQueryModel;

    QSqlQuery * qry=new QSqlQuery(conn.db);
    qry->prepare("select * from Avocats ORDER BY CIN ");
    qry->exec();
    model->setQuery(*qry);
    ui->tableView_avocats->setModel(model);
}


void MainWindow::on_radioButton_triprenom_2_clicked()
{
    Connection conn;
    QSqlQueryModel * model = new QSqlQueryModel;

    QSqlQuery * qry=new QSqlQuery(conn.db);
    qry->prepare("select * from Avocats ORDER BY PRENOM ");
    qry->exec();
    model->setQuery(*qry);
    ui->tableView_avocats->setModel(model);

}


void MainWindow::on_radioButton_trinom_2_clicked()
{
    Connection conn;
    QSqlQueryModel * model = new QSqlQueryModel;

    QSqlQuery * qry=new QSqlQuery(conn.db);
    qry->prepare("select * from Avocats ORDER BY NOM ");
    qry->exec();
    model->setQuery(*qry);
    ui->tableView_avocats->setModel(model);
}

void MainWindow::on_sendBtn_3_clicked()
{
    connect(ui->sendBtn_3, SIGNAL(clicked()),this, SLOT(sendMail()));
    connect(ui->exitBtn_3, SIGNAL(clicked()),this, SLOT(close()));
    connect(ui->browseBtn_4, SIGNAL(clicked()), this, SLOT(browse()));
}

void MainWindow::on_Gestion_des_avocats_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
    ui->Gestion_des_avocats->setCheckable(true);
    ui->gestion_employee_2->setCheckable(false);
    ui->Gestion_des_clients->setCheckable(false);

    ui->Gestion_audience->setCheckable(false);
    ui->Gestion_des_Salle->setCheckable(false);
    ui->gestion_documents->setCheckable(false);
    ui->Gestion_des_avocats->setChecked(true);
}

void MainWindow::on_gestion_employee_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
    ui->gestion_employee_2->setCheckable(true);
    ui->gestion_documents->setCheckable(false);
    ui->Gestion_des_clients->setCheckable(false);

    ui->Gestion_audience->setCheckable(false);
    ui->Gestion_des_Salle->setCheckable(false);
    ui->Gestion_des_avocats->setCheckable(false);
    ui->gestion_employee_2->setChecked(true);
}

void MainWindow::on_gestion_documents_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
    ui->gestion_documents->setCheckable(true);
    ui->gestion_employee_2->setCheckable(false);
    ui->Gestion_des_clients->setCheckable(false);
    ui->Gestion_audience->setCheckable(false);
    ui->Gestion_des_avocats->setCheckable(false);
    ui->Gestion_des_Salle->setCheckable(false);



    ui->gestion_documents->setChecked(true);

}

void MainWindow::on_Close_clicked()
{
    close();
}

void MainWindow::on_Gestion_des_clients_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);
    ui->Gestion_des_clients->setCheckable(true);
    ui->gestion_employee_2->setCheckable(false);
    ui->Gestion_audience->setCheckable(false);
    ui->Gestion_des_Salle->setCheckable(false);
    ui->gestion_documents->setCheckable(false);
    ui->Gestion_des_avocats->setCheckable(false);

    ui->Gestion_des_clients->setChecked(true);
}

/************************************************************MAIN HAJER****************************************************/

void MainWindow::on_ajouter_client_clicked()
{
    int CIN = ui->CIN->text().toInt();
    QString nom= ui->NOM->text();       // ===================> recuperation des information mel formulaire
    QString prenom=ui->prenom_hajer->text();
    int age = ui->age->text().toInt();
    QString img_client=ui->img_f->text();

    if (ui->CIN->text().isEmpty())
     {


        ui->CIN->setStyleSheet("border: 1px solid red ");
         QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP CIN!!!!") ;  // ZINA LI T5ALIK KI TO8LOT FORMULAIRE YECH3EL BEL AHMER
         QToolTip::showText(ui->CIN->mapToGlobal(QPoint(100,0)), tr("INSERT CIN"));
    }else if(ui->NOM->text().isEmpty()||nom.size()>21){


        ui->NOM->setStyleSheet("border: 1px solid red ");
         QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP  NOM!!!!") ;
          QToolTip::showText(ui->NOM->mapToGlobal(QPoint(100,0)), tr("nom doit etre entre 0 et 20 charactere"));
    }
    else if(prenom.isEmpty()||prenom.size()>21){

            ui->prenom_hajer->setStyleSheet("border: 1px solid red ");
             QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP PRENOM!!!!") ;
             QToolTip::showText(ui->prenom_hajer->mapToGlobal(QPoint(100,0)), tr("prenom doit etre entre 0 et 20 charactere"));

        }

    else if(machineImg.isEmpty()){

            ui->img_f->setStyleSheet("border: 1px solid red ");
             QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP img!!!!") ;
             QToolTip::showText(ui->img_f->mapToGlobal(QPoint(100,0)), tr("telecharger une image"));


        }

    if (ui->age->text().isEmpty())
     {


        ui->age->setStyleSheet("border: 1px solid red ");
         QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP CIN!!!!") ;
         QToolTip::showText(ui->CIN->mapToGlobal(QPoint(100,0)), tr("INSERT CIN"));
    }
    else {


  Client_Fonctions C(CIN,nom,prenom,age,machineImg); // 3ABILI El constructor bel les informations eli da5althom
  bool test=C.ajouter(); // 3ayetli lel methode ajouter bech tajoutili fel base de donnees
  if(test)
{

QMessageBox::information(nullptr, QObject::tr("Ajouter un Client"),
                  QObject::tr("Client ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);



}
  else

      QMessageBox::critical(nullptr, QObject::tr("Ajouter un Client"),
                  QObject::tr("CIN Client existe deja  !\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
}
}


void MainWindow::setFormulaire()
{
    if(CIN != -999999999){

        QString NOM="";
        int age=0;
        QString prenom=0;
                                     //================>9a3ed yrecuperilek hasb el CIN

        Client_Fonctions f( CIN, NOM, prenom,  age,  machineImg);

        QSqlQuery ClientInfo = f.afficherClient(CIN);



        ClientInfo.next();
        QPixmap image (ClientInfo.value(4).toString());//get image path
        machineImg = ClientInfo.value(4).toString();

        ui->lblBkImge->setSizePolicy( QSizePolicy::Ignored, QSizePolicy::Ignored );
        image = image.scaled(130,100,Qt::IgnoreAspectRatio,Qt::FastTransformation);

        ui->lblBkImge->setPixmap(image);
        ui->NOM->setText(ClientInfo.value(1).toString());
        ui->img_f->setText(ClientInfo.value(4).toString());
        ui->prenom_hajer->setText(ClientInfo.value(2).toString());
        ui->age->setText(ClientInfo.value(3).toString());



        bool inputsFocus = ui->NOM->hasFocus() || ui->prenom_hajer->hasFocus() || ui->age->hasFocus() || ui->img_f->hasFocus() ;
   /*     int reference=CIN;

        const QrCode qr = QrCode::encodeText(std::to_string(reference).c_str(), QrCode::Ecc::LOW);
        std::ofstream myfile;
        myfile.open ("qrcode.svg") ;
        myfile << qr.toSvgString(1);
        myfile.close();
        QSvgRenderer svgRenderer(QString("qrcode.svg"));
        QPixmap pix( QSize(120, 120) );
        QPainter pixPainter( &pix );
        svgRenderer.render( &pixPainter );
        ui->QRCODE_3->setPixmap(pix);*/

        if(inputsFocus){
            timer->stop();
        }
    }
    timer->stop();
}





void MainWindow::on_add_imageBtn_clicked()
{
    QString imageFile = QFileDialog ::getOpenFileName(0,"Select Image","/home/","Image Files (*.png)"); // ejbedli mel pc mta3i ken les img png

      QFileInfo info(imageFile);
      QFileInfo  filename = info.fileName(); //5outhli path el taswira win mawjouda bethabt

    QPixmap image (imageFile);
      ui->lblBkImge->setSizePolicy( QSizePolicy::Ignored, QSizePolicy::Ignored );// taille el taswira
      image = image.scaled(130,100,Qt::IgnoreAspectRatio,Qt::FastTransformation); // taille el taswira
      ui->lblBkImge->setPixmap(image);
      ui->lblBkImge->show(); // warini el taswira fel blasa eli hatitha fiha
     // qDebug() << image <<endl << imageFile <<endl<<info.fileName();

     machineImg = imageFile;
}



void tablerow::deleteBtn_clicked()
{
    QPushButton* buttonSender = qobject_cast<QPushButton*>(sender()); // ejbedli el boutton mta3 el delete mel position mta3ou li hatitha fel listview
    int CIN = buttonSender->whatsThis().toInt();


    QString nomClient="";
    QString ClientImg="";
    int CINN = 0;
    QString Clientprenom="";
    int age=0;


    Client_Fonctions c(CINN, nomClient, Clientprenom,  age,  ClientImg);

//
    bool test = c.supprimerClient(CIN);

    if(test){
        QMessageBox::information(nullptr, QObject::tr("delete status"),QObject::tr("Client Supprimer.\nClick Cancel to exit."), QMessageBox::Cancel,QMessageBox::NoIcon);
        timer2->start(100);
        timer4->start(100);
    }
    else {
        QMessageBox::critical(nullptr, QObject::tr("delete status"),QObject::tr("Client non Supprimer.\nClick Cancel to exit."), QMessageBox::Cancel);
    }

}





void MainWindow::on_modifier_client_clicked()
{

        QString NOM=ui->NOM->text();
        QString prenom=ui->prenom_hajer->text();
        int age=ui->age->text().toInt();



        Client_Fonctions m(CIN , NOM,  prenom,  age,machineImg);
        bool test = m.modifierClient(CIN);

        if(test){
            QMessageBox::information(nullptr, QObject::tr("update status"),QObject::tr("Client Modifier.\nClick Cancel to exit."), QMessageBox::Cancel,QMessageBox::NoIcon);
            timer2->start(100);
            timer4->start(100);
        }
        else {
            QMessageBox::critical(nullptr, QObject::tr("update status"),QObject::tr("Client Modifier.\nClick Cancel to exit."), QMessageBox::Cancel);
        }
    }

void tablerow::updateBtn_clicked()
{
    QPushButton* buttonSender = qobject_cast<QPushButton*>(sender()); // ajbedli el boutton modifier mel position mta3ou
    CIN = buttonSender->whatsThis().toInt();

    timer->start(100);
}


void MainWindow::setQR()

{ QString nomclient=ui->NOM->text();
    QString prenomclient=ui->prenom_hajer->text();
                                                //  ================> 9a3ed yrecuperi fel hajet el mawjouda fel formulaire wihot fihom fi des variables
    QString CLIENTImg=ui->img_f->text();
    int ageclient=ui->age->text().toInt();
    int cin=ui->CIN->text().toInt();
//    int reference=idd;
    Client_Fonctions m( cin, nomclient,  prenomclient,  ageclient,CLIENTImg);
    QSqlQuery pro_liste = m.afficherClient(CIN);
    pro_liste.next();
    QString reference = pro_liste.value(1).toString() +" | "+ pro_liste.value(2).toString()+" | "+ pro_liste.value(3).toString()+" | "+ pro_liste.value(4).toString();
    QByteArray ba = reference.toLocal8Bit();
    const char *c_str2 = ba.data();
    const QrCode qr = QrCode::encodeText(/*std::to_string(reference).c_str()*/c_str2, QrCode::Ecc::LOW);
    std::ofstream myfile;
    myfile.open ("qrcode.svg") ;
    myfile << qr.toSvgString(1);
    myfile.close();
    QSvgRenderer svgRenderer(QString("qrcode.svg"));
    QPixmap pix( QSize(100, 100) );
    QPainter pixPainter( &pix );
    svgRenderer.render( &pixPainter );
    ui->QRCODE_3->setPixmap(pix);
    bool inputsFocus = ui->QRCODE_3->hasFocus();
    if(inputsFocus){
        timerP3->stop();

    }
}

void tablerow::qr_generator()
{
    QPushButton* buttonSender = qobject_cast<QPushButton*>(sender());
    CIN = buttonSender->whatsThis().toInt();
    timerP3->start(500);
}

void MainWindow::on_search_client_button_clicked()
{
    QString chaine_r=ui->search_c->text();
if(chaine_r !=""){
    timer2->stop();
    timer->start(100);

    while(!layoutt->isEmpty()){
    QLayoutItem* item = layoutt->itemAt(0);
    layoutt->removeItem(item);
    QWidget* widgett = item->widget();
    if(widgett)
        {
            delete widgett;
        }
    }
    QString nomclient=ui->NOM->text();
        QString prenomclient=ui->prenom_hajer->text();
                                                    //  ================> 9a3ed yrecuperi fel hajet el mawjouda fel formulaire wihot fihom fi des variables
        QString CLIENTImg=ui->img_f->text();
        int ageclient=ui->age->text().toInt();
        int cin=ui->CIN->text().toInt();
    Client_Fonctions m( cin, nomclient,  prenomclient,  ageclient,CLIENTImg);
    QSqlQuery pro_liste = m.rechercher(chaine_r);
    while (pro_liste.next()) {
        tablerow *r = new tablerow (ui->scrollArea_hajer,pro_liste.value(0).toString(),pro_liste.value(1).toString(),pro_liste.value(2).toString(),pro_liste.value(3).toString(),pro_liste.value(4).toString());
        r->setMinimumHeight(34);
        layoutt->addWidget( r );
    }}
else{

 timer2->stop();
 timer->start(100);

}


   // connect(timer, SIGNAL(timeout()), this, SLOT(setFormulaire()));
    //timer->start(500);

  //  connect(timer2, SIGNAL(timeout()), this, SLOT(on_refreshBtn_clicked()));
    //timer2->start(50);

}

void MainWindow::on_search_c_textChanged(const QString &arg1)
{
    on_search_client_button_clicked();

}


void MainWindow::on_refresh_clicked()  // fonction afficher
{
    while(!layoutt->isEmpty()){
    QLayoutItem* item = layoutt->itemAt(0);
    layoutt->removeItem(item);
    QWidget* widgett = item->widget();
    if(widgett)
        {
            delete widgett;
        }
    }


    QString nomclient=ui->NOM->text();
    QString prenomclient=ui->prenom_hajer->text();
                                                //  ================> 9a3ed yrecuperi fel hajet el mawjouda fel formulaire wihot fihom fi des variables
    QString CLIENTImg=ui->img_f->text();
    int ageclient=ui->age->text().toInt();
    int cin=ui->CIN->text().toInt();




    Client_Fonctions m( cin, nomclient,  prenomclient,  ageclient,CLIENTImg); // =====> 3aba el constructeur


    QString trieOption = ui->client_combo->currentText();

    QSqlQuery clientList = m.trierclient(trieOption);
    //QSqlQuery clientList = m.afficherClient(); // 3ayet lel fonction afficher
    while (clientList.next()) {
         tablerow *row = new tablerow(ui->scrollArea_hajer,clientList.value(0).toString(),clientList.value(1).toString(),clientList.value(2).toString(),clientList.value(3).toString(), clientList.value(4).toString());
         row->setMinimumHeight(64);
         layoutt->addWidget( row ); // affichili ka3ba wra lo5ra kol matajouti 5alini nescroli
    }


    QStringList CompletionList;
    CompletionList = m.rechercherclient_completer();

    stringCompleter = new QCompleter(CompletionList,this);
    stringCompleter->setCaseSensitivity(Qt::CaseInsensitive);
    ui->search_c->setCompleter(stringCompleter);

    timer2->stop(); // ma3netha wa9efli el timer
}
void MainWindow::on_trier_client_clicked()
{
    on_refresh_clicked();
}

void MainWindow::on_clearBtn_clicked()
{
    ui->NOM->setText("");
    ui->prenom_hajer->setText("");
    ui->age->setText("");
    ui->CIN->setText("");
    ui->img_f->setText("");

}

void MainWindow::on_google_search_button_clicked()
{
    search.show();
}



void MainWindow::on_sms_clicked()
{

    Sms *sms = new Sms();
    sms->setCinClient(CIN);

    sms->show();
}

void MainWindow::on_ardibutton_clicked()
{
    arduino_haj *ardi = new arduino_haj();
    ardi->show();
}
