#ifndef AUDIENCE_H
#define AUDIENCE_H

#include<QString>
#include<QSqlQuery>
#include<QSqlQueryModel>
#include<QDoubleValidator>
#include<QtDebug>
#include<QObject>
#include <QMainWindow>
#include <QDateTime>
#include <QFile>
#include <QMessageBox>


class audience
{
public:

    audience(QString,QString,QString,int,int,QString);
    audience();
        void setcin (QString n);
        void setprenom (QString n);
        void setnom (QString n);
        void setladate (QString n);
        void setnbr_jures(int n);
        void setpersonnes(int n);
        QString get_cin(); /* int dans la video */
        QString get_prenom();
        QString get_nom();
        QString get_date_auj();
        int get_nbrjures();
        int get_personnes();
        bool ajouter();
        QSqlQueryModel* afficher();
        bool supprimer(QString);
        bool modifier();
        QSqlQueryModel* tri_cin();
        QSqlQueryModel* recherche(QString rech);
 QSqlQueryModel* geo();




private:
         QString cin, prenom, nom, date_auj;
         int nbr_jures, personnes;
};

#endif // AUDIENCE_H
