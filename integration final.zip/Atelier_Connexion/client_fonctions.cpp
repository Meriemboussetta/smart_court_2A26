#include "client_fonctions.h"






Client_Fonctions::Client_Fonctions(int CIN,QString nom, QString prenom ,  int age,QString img)
{
    this->nom = nom;
    this->img = img;
    this->CIN = CIN;
    this->prenom = prenom;
    this->age = age;
} // creation des parametres pour le constructeur

bool Client_Fonctions::ajouter() // methode dajout
{
    QSqlQuery query;



    query.prepare("Insert into client(CIN, nom, prenom, age,img)"
                  "Values( :CIN, :nom, :prenom, :age, :img)");     // inserer les donnees dans le tableau
    query.bindValue(":CIN", CIN); // hotli el valeur li da5elthelek fel formulaire fel blasa el mounesba west base de donnee
    query.bindValue(":nom", nom);
    query.bindValue(":prenom", prenom);
    query.bindValue(":age", age);
    query.bindValue(":img", img);


    return query.exec(); // executili el requete eli baathha

}


QSqlQuery Client_Fonctions::afficherClient()
{
    QSqlQuery query;
    query.exec("select * from client"); // ma3netha ejbedli kol chy ay information 3andek fel tableau mta3i
    return query;
}


bool Client_Fonctions::supprimerClient(int CIN)
{
QSqlQuery query;

QString id = QString::number(CIN);

query.prepare("Delete from client where CIN=:CIN");
query.bindValue(":CIN",id);
return query.exec();
}


QSqlQuery Client_Fonctions::afficherClient(int CIN)
{
    QSqlQuery query;
    query.prepare("select * from client where CIN=:CIN");
    query.bindValue(":CIN",CIN);

    query.exec();
    return query;
}

bool Client_Fonctions::modifierClient(int CIN)
{
    QSqlQuery query;
    query.prepare("update client set CIN=:CIN, img=:img, age=:age, nom=:nom , prenom=:prenom where CIN=:CIN");
    query.bindValue(":CIN", CIN);
    query.bindValue(":nom", nom);
    query.bindValue(":prenom", prenom);
    query.bindValue(":age", age);
    query.bindValue(":img", img);
    return query.exec();


}

QSqlQuery Client_Fonctions::rechercher(QString chaine)// recherche
{

    QSqlQuery query;

    query.exec("SELECT * from CLIENT where CIN LIKE'"+chaine+"%' OR NOM LIKE'"+chaine+"%' OR PRENOM LIKE'"+chaine+"%'");
    return query;


}


QSqlQuery Client_Fonctions::trierclient(QString test)// tri
{
    QSqlQuery query;
    if(test == "par défaut"){
        query.exec("select * from client");
    }
    else if(test =="nom")
    {
        query.exec("select * from client order by nom asc");
    }
    else if(test =="prenom")
    {
        query.exec("select * from client order by prenom desc");
    }
    else if(test =="age")
    {
        query.exec("select * from client order by age asc");
    }

    return query;
}
QStringList Client_Fonctions::rechercherclient_completer()// recherche instantanée
{

    QSqlQuery query;
    QStringList cblist;

    query.prepare("select * from client ");
    query.exec();

    QString n;
    while(query.next())
            {
                cblist.push_back(query.value(1).toString() );
                cblist.push_back(query.value(2).toString() );
             //   qDebug() << "test";

            }


    return  cblist;


}


