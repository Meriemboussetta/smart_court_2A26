#include "audience.h"
#include <QSqlQuery>
#include <QtDebug>
#include <QString>
#include<QtDebug>
#include<QObject>
#include <QMainWindow>
#include <QDateTime>
#include <QFile>
#include <QMessageBox>
#include <QSqlQueryModel>
#include<QDesktopServices>
#include <QSqlQuery>
#include <QtDebug>
#include <QString>
#include<QtDebug>
#include<QObject>
#include <QMainWindow>
#include <QDateTime>
#include <QFile>
#include <QMessageBox>
#include <QTimer>
#include<QDateTime>

#include"QDate"
#include <QTime>
#include <QTimer>
#include <QSqlQueryModel>
#include <QtGui/QIntValidator>
#include<QIntValidator>
#include<QMessageBox>
#include<QDesktopServices>
#include<QFileDialog>
#include <QPushButton>
#include "connection.h"
#include<QString>
#include<QSqlQuery>
#include<QSqlQueryModel>
#include<QDoubleValidator>
#include<QtDebug>
#include<QObject>
#include <QMainWindow>
#include <QDateTime>
#include <QFile>
#include <QMessageBox>

#include <QTabWidget>
#include <QTableWidgetItem>
#include <QtDebug>
#include <QIntValidator>
#include <QMessageBox>
#include <QDate>
#include <QTextDocument>
#include "QtPrintSupport"

audience::audience()
{
    cin="";
    prenom="";
    nom="";
    date_auj="";
    personnes=0;
    nbr_jures=0;

}

audience::audience(QString cin, QString prenom, QString nom, int nbr_jures, int personnes, QString date_auj)
{
    this->cin=cin;
    this->prenom=prenom;
    this->nom=nom;
    this->nbr_jures=nbr_jures;
    this->personnes=personnes;
    this->date_auj=date_auj;

}

void audience::setcin(QString c_cin){this->cin=c_cin;}
void audience::setprenom(QString c_prenom){this->prenom=c_prenom;}
void audience::setnom(QString c_nom){this->nom=c_nom;}
void audience::setladate(QString date_auj){this->date_auj=date_auj;}
void audience::setnbr_jures (int nbr_jures) {this->nbr_jures=nbr_jures;}
void audience::setpersonnes(int personnes){this->personnes=personnes;}


QString audience::get_cin(){return cin;}
QString audience::get_prenom(){return prenom;}
QString audience::get_nom(){return nom;}
QString audience::get_date_auj(){return date_auj;}
int audience::get_nbrjures(){return nbr_jures;}
int audience::get_personnes(){return personnes;}

bool audience::ajouter()
{
    QSqlQuery query;
         query.prepare("INSERT INTO AUDIENCE (CIN, NOM, PRENOM, NBR_JURES, PERSONNES ) "
                       "VALUES (:CIN, :NOM, :PRENOM, :NBR_JURES, :PERSONNES)");
         query.bindValue(0, cin);
         query.bindValue(1, nom);
         query.bindValue(2, prenom);
         query.bindValue(3, nbr_jures);
         query.bindValue(4, personnes);
         return query.exec();

}


QSqlQueryModel* audience::afficher()
{
  QSqlQueryModel* model=new QSqlQueryModel();



        model->setQuery("SELECT* FROM AUDIENCE");
        model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
        model->setHeaderData(1, Qt::Horizontal, QObject::tr("NOM"));
        model->setHeaderData(2, Qt::Horizontal, QObject::tr("PRENOM"));
        model->setHeaderData(3, Qt::Horizontal, QObject::tr("NBR_JURES"));
        model->setHeaderData(4, Qt::Horizontal, QObject::tr("DATE_AUD"));
        model->setHeaderData(5, Qt::Horizontal, QObject::tr("PERSONNES"));

return model;

}

bool audience ::supprimer(QString id)
{
    QSqlQuery query;

          query.prepare("Delete from AUDIENCE where CIN=:id");
          query.bindValue(0, id);

           return  query.exec();

}


bool audience::modifier()
{
    QSqlQuery query;
 query.prepare("update AUDIENCE  set NOM=:nom,PRENOM=:prenom,NBR_JURES=:NBR_JURES,PERSONNES=:PERSONNES where CIN like :cin");
query.bindValue(":cin",this->cin);
query.bindValue(":nom",this->nom);
query.bindValue(":prenom",this->prenom);
query.bindValue(":NBR_JURES",this->nbr_jures);
query.bindValue(":PERSONNES",this->personnes);

     return  query.exec();


}

QSqlQueryModel * audience::tri_cin()
{
    QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from AUDIENCE order by CIN");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("NOM"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("PRENOM"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("NBR_JURES"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("DATE_AUD"));
model->setHeaderData(5, Qt::Horizontal, QObject::tr("PERSONNES"));




    return model;
}


QSqlQueryModel* audience::recherche(QString rech)
 {

         QSqlQueryModel * model= new QSqlQueryModel();
         model->setQuery("SELECT * FROM AUDIENCE WHERE CIN LIKE '"+rech+"%'" );
         model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
         model->setHeaderData(1, Qt::Horizontal, QObject::tr("NOM"));
         model->setHeaderData(2, Qt::Horizontal, QObject::tr("PRENOM"));


    return model;




 }
QSqlQueryModel * audience::geo()
{
    QString link="https://www.google.com/maps/dir//minist%C3%A8re+de+la+justice+Bd+Bab+Benet+Tunis/@36.8011442,10.1653361,16z/data=!4m8!4m7!1m0!1m5!1m1!1s0x12fd338b8d6f60fd:0x6ab7edee0c5e0092!2m2!1d10.1653361!2d36.8011442";
    QDesktopServices::openUrl(link);}



