#include "arduino_hajer.h"
#include "ui_arduino_hajer.h"
#include <QtSerialPort>
#include <QSerialPortInfo>
#include <QtWidgets>


arduino_hajer::arduino_hajer(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::arduino_hajer)
{
    ui->setupUi(this);

    ard = new QSerialPort;
    port_name = "";
    ada_arduino = false;
    serialbuffer = "";

    foreach (const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts()) {
       if(serialPortInfo.hasVendorIdentifier() && serialPortInfo.hasProductIdentifier()){
           if(serialPortInfo.vendorIdentifier() == vendor_id){
               if(serialPortInfo.productIdentifier() == produk_id){
                   port_name = serialPortInfo.portName();
                   ada_arduino = true;
               }
           }
       }
    }
    if(ada_arduino){
        ard->setPortName(port_name);
        ard->open(QSerialPort::ReadWrite);
        ard->setBaudRate(QSerialPort::Baud9600);
        ard->setDataBits(QSerialPort::Data8);
        ard->setFlowControl(QSerialPort::NoFlowControl);
        ard->setParity(QSerialPort::NoParity);
        ard->setStopBits(QSerialPort::OneStop);
        QObject::connect(ard, SIGNAL(readyRead()), this, SLOT(BacaSerial()));
    }else{
        QMessageBox::warning(this, "Error", "Arduino tidak terkoneksi");
    }
}

arduino_hajer::~arduino_hajer()
{
    delete ui;
    if(ard->isOpen()){
        ard->close();
    }


}

void arduino_hajer::BacaSerial(){
    QStringList splitdata = serialbuffer.split(", ");
    if(splitdata.length() < 3){
        dataserial = ard->readAll();
        serialbuffer += QString::fromStdString(dataserial.toStdString());
    }else{
        serialbuffer = "";

        QStringList datasensor = serialbuffer2.split("data1:");
        if(datasensor.length() < 3){
            serialbuffer2 += QString::fromStdString(splitdata[0].toStdString());
        }else{
            serialbuffer2="";
            arduino_hajer::UpdateDataSensor(datasensor[1]);
        }


        QStringList dataled = serialbuffer3.split("data2:");
        if(dataled.length() < 3){
            serialbuffer3 += QString::fromStdString(splitdata[1].toStdString());
        }else{
            serialbuffer3="";
            arduino_hajer::UpdateDataLed(dataled[1]);
        }

    }
}

void arduino_hajer::UpdateDataSensor(const QString data){
    ui->lbcount->setText(data + " cm");
}

void arduino_hajer::UpdateDataLed(const QString data){
    if(data == "1"){
        ui->lbstatus->setText("ON");
    }else{
        ui->lbstatus->setText("OFF");
    }
}


void arduino::on_offbutton_clicked()
{
    if(ard->isWritable()){
        ard->write("0");
    }
}
