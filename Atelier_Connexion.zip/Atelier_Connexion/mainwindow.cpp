#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "employee.h"
#include <QMessageBox>
#include <QIntValidator>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{

    ui->setupUi(this);
   ui->id->setValidator( new QIntValidator(100, 9999999, this));
   ui->tab_employee->setModel(E.afficher());
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_ajouter_clicked()
{
    int id=ui->id->text().toInt();
    QString nom=ui->nom->text();
    QString prenom=ui->prenom->text();
    Employee E(id,nom,prenom);
    bool test=E.ajouter();
        if (test)
        {QMessageBox::information(nullptr, QObject::tr("OK"),
                                QObject::tr("Ajout effectué.\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);
        ui->tab_employee->setModel(E.afficher());}


                else
                    QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                                QObject::tr("Ajout non effectué.\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_supprimer_clicked()
{
    Employee E1; E1.setid(ui->id_supp->text().toInt());
    bool test=E1.supprimer(E1.getid());
   { QMessageBox::information(nullptr, QObject::tr("OK"),
                                    QObject::tr("suppression effectué.\n"
                                                "Click Cancel to exit."), QMessageBox::Cancel);}
if (test){
    QObject::tr("suppression effectué.\n");
    ui->tab_employee->setModel(E.afficher());



}

    else
        QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                    QObject::tr("Ajout non effectué.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_pushButton_clicked()
{
    int id=ui->lineEdit->text().toInt();
    QString nom=ui->lineEdit_2->text();
    QString prenom=ui->lineEdit_3->text();
    int Rid=ui->lineEdit_4->text().toInt();
    Employee E(id,nom,prenom);
    bool test=E.modifier(Rid);
        if (test)
        {QMessageBox::information(nullptr, QObject::tr("OK"),
                                QObject::tr("modification effectué.\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);
        ui->tab_employee->setModel(E.afficher());}


                else
                    QMessageBox::critical(nullptr, QObject::tr("NOT OK"),
                                QObject::tr("modification non effectué.\n"
                                            "Click Cancel to exit."), QMessageBox::Cancel);
}
