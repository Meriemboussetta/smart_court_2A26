#include "employee.h"
#include <QSqlQuery>
#include <QtDebug>
#include <QObject>
Employee::Employee()
{
id=0; nom=" "; prenom="";
}
Employee::Employee(int id,QString nom,QString prenom)
{this->id=id;this->nom=nom;this->prenom=prenom;}
int Employee::getid(){return id;}
QString Employee::getnom(){return nom;}
QString Employee::getprenom(){return prenom;}
void Employee::setid(int id){this->id=id;}
void Employee::setnom(QString nom){this->nom=nom;}
void Employee::setprenom(QString prenom){this->prenom=prenom;}


bool Employee::ajouter()
{


    QString id_string= QString::number(id);
     QSqlQuery query;
          query.prepare("INSERT INTO employee (id, nom, prenom) "
                        "VALUES (:id, :forename, :surname)");
          query.bindValue(":id", id_string);
          query.bindValue(":forename", nom);
          query.bindValue(":surname", prenom);

    return query.exec();
}
bool Employee::supprimer(int id)
{


    QSqlQuery query;
         query.prepare("Delete from employee where id=:id");
         query.bindValue(":id", id);

   return query.exec();


}
QSqlQueryModel* Employee::afficher()
{
  QSqlQueryModel* model=new QSqlQueryModel();


  model->setQuery("SELECT* FROM employee");
  model->setHeaderData(0, Qt::Horizontal, QObject::tr("Identifiant"));
  model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
  model->setHeaderData(2, Qt::Horizontal, QObject::tr("prenom"));


  return model;

}
bool Employee::modifier(int RID){
 QSqlQuery query;
      query.prepare("UPDATE employee SET id= :id, nom= :forename , prenom= :surname WHERE id= :RID ");
      query.bindValue(":RID", RID);
      query.bindValue(":id", id);
      query.bindValue(":forename", nom);
      query.bindValue(":surname", prenom);

return query.exec();
}




